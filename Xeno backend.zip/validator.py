import os
import re
import pandas as pd
import numpy as np
from datetime import datetime
import zipfile
from backend.config import REQUIRED_COLUMNS, ALLOWED_PAYMENT_MODES, ALLOWED_PAYMENT_STATUSES, UPLOAD_FOLDER
from backend.database import get_all_rules

def parse_date_with_formats(val):
    """
    Attempts to parse date using DD-MM-YYYY, DD-MM-YYYY HH:MM:SS, or DD-MM-YYYY HH:MM.
    Returns datetime object or None if invalid.
    """
    if pd.isna(val) or not str(val).strip():
        return None
        
    date_str = str(val).strip()
    formats = [
        "%d-%m-%Y",
        "%d-%m-%Y %H:%M:%S",
        "%d-%m-%Y %H:%M"
    ]
    
    for fmt in formats:
        try:
            return datetime.strptime(date_str, fmt)
        except ValueError:
            continue
    return None

def validate_transaction_file(file_path, original_filename):
    """
    Validates the transaction CSV file and saves output reports.
    Returns:
        dict: contains stats, preview, error list, download paths, chunk stats
    """
    # 1. Inspect lines to skip any leading empty/delimiter-only rows and determine encoding
    encoding = 'utf-8-sig'
    try:
        with open(file_path, 'r', encoding=encoding) as f:
            lines = f.readlines()
    except UnicodeDecodeError:
        encoding = 'latin1'
        try:
            with open(file_path, 'r', encoding=encoding) as f:
                lines = f.readlines()
        except Exception as e:
            return {
                "success": False,
                "error": f"Failed to read file lines: {str(e)}"
            }
    except Exception as e:
        return {
            "success": False,
            "error": f"Failed to read file lines: {str(e)}"
        }

    header_idx = 0
    for idx, line in enumerate(lines):
        # Strip BOM, carriage return, newlines, spaces, and delimiters to check if actual header words exist
        clean_line = line.replace('\ufeff', '').strip(' \t\n\r,;')
        if clean_line:
            header_idx = idx
            break

    # 2. Load CSV using Pandas, skipping prepended empty lines
    try:
        # Try python engine with auto-detection of separators (comma, semicolon, tab)
        df = pd.read_csv(file_path, dtype=str, encoding=encoding, skiprows=header_idx, sep=None, engine='python')
    except Exception as e:
        try:
            # Fallback to standard comma separator
            df = pd.read_csv(file_path, dtype=str, encoding=encoding, skiprows=header_idx)
        except Exception as e2:
            return {
                "success": False,
                "error": f"Failed to parse CSV: {str(e2)}"
            }

    total_records = len(df)
    
    # 3. Clean columns (case-insensitive, whitespace/quote-trimmed, and BOM-stripped)
    cleaned_cols = []
    clean_to_original = {}
    for c in df.columns:
        # Strip UTF-8 BOM, surrounding spaces, tabs, newlines, carriage returns, and quotes, then lowercase
        clean_name = str(c).replace('\ufeff', '').strip(' \t\n\r"\'').lower()
        cleaned_cols.append(clean_name)
        clean_to_original[clean_name] = c
    df.columns = cleaned_cols
    
    missing_cols = [col for col in REQUIRED_COLUMNS if col not in df.columns]
    if missing_cols:
        # Write detailed file parameters to a debug log to inspect exactly what columns were received
        try:
            debug_log_path = os.path.join(UPLOAD_FOLDER, "debug_headers.log")
            with open(debug_log_path, "w", encoding="utf-8") as debug_file:
                debug_file.write(f"Original Filename: {original_filename}\n")
                debug_file.write(f"Detected Encoding: {encoding}\n")
                debug_file.write(f"Detected Separator: {detected_sep}\n")
                debug_file.write(f"Header Row Index: {header_idx}\n")
                debug_file.write(f"Raw df.columns: {list(df.columns)}\n")
                debug_file.write(f"Cleaned Columns: {cleaned_cols}\n")
                debug_file.write(f"Missing Columns: {missing_cols}\n")
                with open(file_path, "rb") as rf:
                    debug_file.write(f"First 200 raw bytes: {rf.read(200)}\n")
        except Exception:
            pass

        import sys
        print(f"[Header Error] Missing mandatory columns: {missing_cols}", file=sys.stderr)
        print(f"[Header Error] Received columns: {df.columns.tolist()}", file=sys.stderr)
        return {
            "success": False,
            "error": f"Missing mandatory columns: {', '.join(missing_cols)}"
        }

    # Fetch active country rules from SQLite database
    active_rules = get_all_rules()

    errors = []
    valid_rows_mask = np.ones(total_records, dtype=bool)
    rejection_reasons_col = [""] * total_records
    
    # Track seen order IDs to flag duplicates
    seen_order_ids = {}
    
    # Keep track of duplicate order IDs in a pass to flag subsequent duplicates
    order_id_counts = df["order_id"].value_counts()

    # 3. Row-by-row validation
    for i, row in df.iterrows():
        row_errors = []
        excel_row_num = i + 2 # Header is row 1, data starts at row 2

        # Order ID checks
        order_id = str(row["order_id"]).strip() if not pd.isna(row["order_id"]) else ""
        if not order_id:
            row_errors.append(("order_id", "Empty mandatory field"))
        else:
            if order_id in seen_order_ids:
                row_errors.append(("order_id", f"Duplicate order ID (already seen in row {seen_order_ids[order_id]})"))
            else:
                seen_order_ids[order_id] = excel_row_num

        # Customer ID checks
        cust_id = str(row["customer_id"]).strip() if not pd.isna(row["customer_id"]) else ""
        if not cust_id:
            row_errors.append(("customer_id", "Empty mandatory field"))

        # Date checks
        tx_date_raw = str(row["transaction_date"]).strip() if not pd.isna(row["transaction_date"]) else ""
        if not tx_date_raw:
            row_errors.append(("transaction_date", "Empty mandatory field"))
        else:
            dt = parse_date_with_formats(tx_date_raw)
            if dt is None:
                row_errors.append(("transaction_date", "Invalid date format or value. Expected format: DD-MM-YYYY (with optional HH:MM)"))

        # Product name checks
        p_name = str(row["product_name"]).strip() if not pd.isna(row["product_name"]) else ""
        if not p_name:
            row_errors.append(("product_name", "Empty mandatory field"))

        # Product category checks
        p_cat = str(row["product_category"]).strip() if not pd.isna(row["product_category"]) else ""
        if not p_cat:
            row_errors.append(("product_category", "Empty mandatory field"))

        # Quantity checks
        qty_raw = str(row["quantity"]).strip() if not pd.isna(row["quantity"]) else ""
        if not qty_raw:
            row_errors.append(("quantity", "Empty mandatory field"))
        else:
            try:
                # Must be integer
                qty = int(qty_raw)
                if qty <= 0:
                    row_errors.append(("quantity", "Quantity must be a positive integer (> 0)"))
            except ValueError:
                row_errors.append(("quantity", "Quantity must be a valid numeric integer"))

        # Amount checks
        amt_raw = str(row["amount"]).strip() if not pd.isna(row["amount"]) else ""
        if not amt_raw:
            row_errors.append(("amount", "Empty mandatory field"))
        else:
            try:
                amt = float(amt_raw)
                if amt < 0:
                    row_errors.append(("amount", "Amount cannot be negative"))
            except ValueError:
                row_errors.append(("amount", "Amount must be a valid numeric decimal"))

        # Payment Mode checks
        pay_mode = str(row["payment_mode"]).strip() if not pd.isna(row["payment_mode"]) else ""
        if not pay_mode:
            row_errors.append(("payment_mode", "Empty mandatory field"))
        elif pay_mode.lower() not in [pm.lower() for pm in ALLOWED_PAYMENT_MODES]:
            row_errors.append(("payment_mode", f"Invalid payment mode '{pay_mode}'. Allowed: {', '.join(ALLOWED_PAYMENT_MODES)}"))

        # Payment Status checks
        pay_status = str(row["payment_status"]).strip() if not pd.isna(row["payment_status"]) else ""
        if not pay_status:
            row_errors.append(("payment_status", "Empty mandatory field"))
        elif pay_status.lower() not in [ps.lower() for ps in ALLOWED_PAYMENT_STATUSES]:
            row_errors.append(("payment_status", f"Invalid payment status '{pay_status}'. Allowed: {', '.join(ALLOWED_PAYMENT_STATUSES)}"))

        # Country validation
        country = str(row["country"]).strip() if not pd.isna(row["country"]) else ""
        if not country:
            row_errors.append(("country", "Empty mandatory field"))
        elif country not in active_rules:
            row_errors.append(("country", f"Invalid country '{country}'. Check configured rules."))

        # Phone Number validation
        phone_raw = str(row["phone_number"]).strip() if not pd.isna(row["phone_number"]) else ""
        if not phone_raw:
            row_errors.append(("phone_number", "Empty mandatory field"))
        elif country in active_rules:
            # Clean non-digits for evaluation (strip +, -, spaces, braces)
            cleaned_phone = re.sub(r"\D", "", phone_raw)
            rule = active_rules[country]
            
            # Match regex
            if not re.match(rule["regex"], cleaned_phone):
                row_errors.append((
                    "phone_number", 
                    f"Invalid phone number format for {country}. Expected exactly {rule['length']} digits."
                ))

        # Check if row has any errors
        if row_errors:
            valid_rows_mask[i] = False
            rejection_reasons_col[i] = "; ".join([f"{col}: {err}" for col, err in row_errors])
            for col, err in row_errors:
                errors.append({
                    "row_number": excel_row_num,
                    "column_name": col,
                    "error_value": row.get(col, ""),
                    "error_reason": err
                })

    valid_count = int(np.sum(valid_rows_mask))
    invalid_count = total_records - valid_count
    success_percentage = (valid_count / total_records * 100) if total_records > 0 else 0

    # 4. Generate outputs
    base_name = os.path.splitext(original_filename)[0]
    timestamp_suffix = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    clean_filename = f"clean_{base_name}_{timestamp_suffix}.csv"
    error_filename = f"error_{base_name}_{timestamp_suffix}.csv"
    zip_filename = f"split_{base_name}_{timestamp_suffix}.zip"
    
    clean_file_path = os.path.join(UPLOAD_FOLDER, clean_filename)
    error_file_path = os.path.join(UPLOAD_FOLDER, error_filename)
    zip_file_path = os.path.join(UPLOAD_FOLDER, zip_filename)

    # Restore original column names for output files
    rename_back_map = {clean_name: clean_to_original[clean_name] for clean_name in df.columns}

    # Clean CSV
    clean_df = df[valid_rows_mask].copy()
    clean_df.rename(columns=rename_back_map, inplace=True)
    clean_df.to_csv(clean_file_path, index=False)
    
    # Error CSV
    error_df = df[~valid_rows_mask].copy()
    error_df.rename(columns=rename_back_map, inplace=True)
    error_df["rejection_reasons"] = [rejection_reasons_col[idx] for idx in range(total_records) if not valid_rows_mask[idx]]
    error_df.to_csv(error_file_path, index=False)

    # 5. Large File Handling (Chunking)
    split_chunks_info = []
    zip_created = False
    
    if total_records > 1000:
        chunk_size = 500
        total_chunks = int(np.ceil(len(clean_df) / chunk_size))
        
        if total_chunks > 0:
            zip_created = True
            with zipfile.ZipFile(zip_file_path, 'w', zipfile.ZIP_DEFLATED) as zip_file:
                for chunk_idx in range(total_chunks):
                    chunk_start = chunk_idx * chunk_size
                    chunk_end = min((chunk_idx + 1) * chunk_size, len(clean_df))
                    chunk_df = clean_df.iloc[chunk_start:chunk_end]
                    
                    chunk_name = f"clean_{base_name}_part_{chunk_idx + 1}.csv"
                    temp_chunk_path = os.path.join(UPLOAD_FOLDER, chunk_name)
                    chunk_df.to_csv(temp_chunk_path, index=False)
                    
                    # Add to zip
                    zip_file.write(temp_chunk_path, chunk_name)
                    # Delete temp chunk CSV file from storage, keeping only the ZIP
                    os.remove(temp_chunk_path)
                    
                    split_chunks_info.append({
                        "chunk_name": chunk_name,
                        "records_count": len(chunk_df),
                        "part_number": chunk_idx + 1
                    })
    
    # Raw file preview (first 5 rows)
    # Convert df representation to JSON friendly dict format
    preview_rows = df.head(10).replace({np.nan: None}).to_dict(orient="records")

    return {
        "success": True,
        "total_records": total_records,
        "valid_count": valid_count,
        "invalid_count": invalid_count,
        "success_percentage": success_percentage,
        "preview_data": preview_rows,
        "errors": errors,
        "clean_file_path": clean_filename,
        "error_file_path": error_filename,
        "split_zip_path": zip_filename if zip_created else None,
        "split_chunks": split_chunks_info,
        "zip_created": zip_created
    }
