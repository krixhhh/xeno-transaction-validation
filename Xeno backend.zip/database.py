import sqlite3
import os
import json
from datetime import datetime
from backend.config import DATABASE_PATH, DEFAULT_PHONE_RULES

def get_db_connection():
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # 1. Validation History Table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS validation_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT NOT NULL,
            timestamp TEXT NOT NULL,
            total_records INTEGER NOT NULL,
            valid_count INTEGER NOT NULL,
            invalid_count INTEGER NOT NULL,
            success_percentage REAL NOT NULL,
            summary TEXT,
            clean_file_path TEXT,
            error_file_path TEXT,
            split_zip_path TEXT
        )
    ''')
    
    # 2. Error Logs Table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS error_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            job_id INTEGER NOT NULL,
            row_number INTEGER NOT NULL,
            column_name TEXT NOT NULL,
            error_value TEXT,
            error_reason TEXT NOT NULL,
            FOREIGN KEY (job_id) REFERENCES validation_history (id) ON DELETE CASCADE
        )
    ''')
    
    # 3. Country Validation Rules Table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS phone_rules (
            country TEXT PRIMARY KEY,
            length INTEGER NOT NULL,
            regex TEXT NOT NULL
        )
    ''')
    
    # Insert default validation rules if empty
    cursor.execute("SELECT COUNT(*) FROM phone_rules")
    if cursor.fetchone()[0] == 0:
        for country, rules in DEFAULT_PHONE_RULES.items():
            cursor.execute(
                "INSERT INTO phone_rules (country, length, regex) VALUES (?, ?, ?)",
                (country, rules["length"], rules["regex"])
            )
            
    conn.commit()
    conn.close()
    print("Database initialized successfully.")

# Phone rules CRUD helpers
def get_all_rules():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM phone_rules")
    rows = cursor.fetchall()
    conn.close()
    return {row["country"]: {"length": row["length"], "regex": row["regex"]} for row in rows}

def save_rule(country, length, regex):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT OR REPLACE INTO phone_rules (country, length, regex) VALUES (?, ?, ?)",
        (country, length, regex)
    )
    conn.commit()
    conn.close()

def delete_rule(country):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM phone_rules WHERE country = ?", (country,))
    conn.commit()
    conn.close()

# History and log helpers
def save_validation_run(filename, total_records, valid_count, invalid_count, success_percentage, summary, clean_path, error_path, zip_path, errors):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # Insert validation run summary
    cursor.execute('''
        INSERT INTO validation_history 
        (filename, timestamp, total_records, valid_count, invalid_count, success_percentage, summary, clean_file_path, error_file_path, split_zip_path) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (filename, timestamp, total_records, valid_count, invalid_count, success_percentage, summary, clean_path, error_path, zip_path))
    
    job_id = cursor.lastrowid
    
    # Insert individual error logs
    for error in errors:
        cursor.execute('''
            INSERT INTO error_logs (job_id, row_number, column_name, error_value, error_reason)
            VALUES (?, ?, ?, ?, ?)
        ''', (job_id, error["row_number"], error["column_name"], str(error["error_value"]), error["error_reason"]))
        
    conn.commit()
    conn.close()
    return job_id

def get_history():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM validation_history ORDER BY id DESC")
    rows = cursor.fetchall()
    conn.close()
    
    history = []
    for row in rows:
        history.append({
            "id": row["id"],
            "filename": row["filename"],
            "timestamp": row["timestamp"],
            "total_records": row["total_records"],
            "valid_count": row["valid_count"],
            "invalid_count": row["invalid_count"],
            "success_percentage": row["success_percentage"],
            "summary": row["summary"],
            "clean_file_path": row["clean_file_path"],
            "error_file_path": row["error_file_path"],
            "split_zip_path": row["split_zip_path"]
        })
    return history

def get_errors_for_job(job_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM error_logs WHERE job_id = ? ORDER BY row_number ASC", (job_id,))
    rows = cursor.fetchall()
    conn.close()
    
    errors = []
    for row in rows:
        errors.append({
            "id": row["id"],
            "job_id": row["job_id"],
            "row_number": row["row_number"],
            "column_name": row["column_name"],
            "error_value": row["error_value"],
            "error_reason": row["error_reason"]
        })
    return errors

def get_all_error_logs(limit=200):
    # Fetch across all recent runs
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT el.*, vh.filename, vh.timestamp 
        FROM error_logs el
        JOIN validation_history vh ON el.job_id = vh.id
        ORDER BY el.id DESC LIMIT ?
    ''', (limit,))
    rows = cursor.fetchall()
    conn.close()
    
    logs = []
    for row in rows:
        logs.append({
            "id": row["id"],
            "job_id": row["job_id"],
            "filename": row["filename"],
            "timestamp": row["timestamp"],
            "row_number": row["row_number"],
            "column_name": row["column_name"],
            "error_value": row["error_value"],
            "error_reason": row["error_reason"]
        })
    return logs
