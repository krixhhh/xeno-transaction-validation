import collections

def generate_ai_summary(total_records, valid_count, invalid_count, errors):
    if total_records == 0:
        return "No transactions were uploaded. Please select a valid CSV dataset to process."
        
    success_percentage = (valid_count / total_records) * 100
    
    if invalid_count == 0:
        return (
            f"Successfully processed {total_records} records. 100% of the transactions passed all "
            f"integrity checks. No data quality issues were detected. The dataset is fully validated and ready for use."
        )
        
    # Analyze errors
    columns_with_errors = []
    error_reasons = []
    country_errors = []
    
    for err in errors:
        columns_with_errors.append(err.get("column_name", ""))
        error_reasons.append(err.get("error_reason", ""))
        if err.get("column_name") == "phone_number" or err.get("column_name") == "country":
            # phone/country issues
            pass
            
    col_counts = collections.Counter([c for c in columns_with_errors if c])
    reason_counts = collections.Counter([r for r in error_reasons if r])
    
    most_common_col = col_counts.most_common(1)[0][0] if col_counts else "unknown"
    most_common_reason = reason_counts.most_common(1)[0][0] if reason_counts else "validation rules"
    
    # Beautify common columns/reasons
    col_display = most_common_col.replace("_", " ").title()
    
    summary_sentence = (
        f"{total_records} transaction records processed. {valid_count} valid records and {invalid_count} invalid records. "
        f"The data validation success rate is {success_percentage:.1f}%. "
        f"The most common issue was found in the '{col_display}' field, specifically: '{most_common_reason}'."
    )
    
    # Add actionable operational recommendation
    recommendation = ""
    if most_common_col == "phone_number":
        recommendation = " Recommendation: Operations team should verify country-specific telephone formats. Ensure Indian numbers are 10 digits and Singaporean numbers are 8 digits before resubmission."
    elif most_common_col == "amount":
        recommendation = " Recommendation: Audit the billing system outputs to ensure product amount fields do not contain negative values."
    elif most_common_col == "order_id":
        recommendation = " Recommendation: Investigate duplicate transaction exports to prevent order ID collisions in operations."
    elif most_common_col == "transaction_date":
        recommendation = " Recommendation: Standardize the date-time output format to DD-MM-YYYY in your export configuration."
    else:
        recommendation = f" Recommendation: Review rows marked with '{most_common_reason}' to resolve formatting and integrity discrepancies."
        
    return summary_sentence + recommendation
