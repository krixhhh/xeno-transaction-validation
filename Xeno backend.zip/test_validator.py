import os
import unittest
import pandas as pd
import shutil
from backend.config import UPLOAD_FOLDER
from backend.database import init_db, save_rule
from backend.validator import validate_transaction_file

class TestValidator(unittest.TestCase):
    
    @classmethod
    def setUpClass(cls):
        # Initialize SQLite DB
        init_db()
        # Insert a couple of extra rules for testing
        save_rule("India", 10, r"^\d{10}$")
        save_rule("Singapore", 8, r"^\d{8}$")
        save_rule("United States", 10, r"^\d{10}$")
        
        # Create a test directory inside upload folder if needed
        cls.test_dir = os.path.join(UPLOAD_FOLDER, "test_runs")
        if not os.path.exists(cls.test_dir):
            os.makedirs(cls.test_dir)
            
    @classmethod
    def tearDownClass(cls):
        # Clean up test files
        if os.path.exists(cls.test_dir):
            shutil.rmtree(cls.test_dir)

    def test_valid_transactions(self):
        # 1. Create a valid CSV file
        csv_path = os.path.join(self.test_dir, "valid_data.csv")
        df = pd.DataFrame([
            {
                "order_id": "TXN-101", "transaction_date": "18-06-2026", "customer_id": "C-1",
                "product_name": "T-Shirt", "product_category": "Apparel", "quantity": "3", "amount": "45.00",
                "payment_mode": "Credit Card", "payment_status": "Success", "country": "India", "phone_number": "9876543210"
            },
            {
                "order_id": "TXN-102", "transaction_date": "19-06-2026 14:30:00", "customer_id": "C-2",
                "product_name": "Coffee Mug", "product_category": "Home Goods", "quantity": "1", "amount": "12.50",
                "payment_mode": "UPI", "payment_status": "Success", "country": "Singapore", "phone_number": "81234567"
            }
        ])
        df.to_csv(csv_path, index=False)
        
        # 2. Run validator
        result = validate_transaction_file(csv_path, "valid_data.csv")
        
        # 3. Assert assertions
        self.assertTrue(result["success"])
        self.assertEqual(result["total_records"], 2)
        self.assertEqual(result["valid_count"], 2)
        self.assertEqual(result["invalid_count"], 0)
        self.assertEqual(len(result["errors"]), 0)
        self.assertIsNone(result["split_zip_path"])

    def test_invalid_transactions(self):
        # 1. Create an invalid CSV file
        csv_path = os.path.join(self.test_dir, "invalid_data.csv")
        df = pd.DataFrame([
            {
                # Duplicate order_id, negative amount, invalid phone length for Singapore (needs 8)
                "order_id": "TXN-201", "transaction_date": "18-06-2026", "customer_id": "C-1",
                "product_name": "T-Shirt", "product_category": "Apparel", "quantity": "3", "amount": "-45.00",
                "payment_mode": "Credit Card", "payment_status": "Success", "country": "Singapore", "phone_number": "91234"
            },
            {
                # Duplicate order_id, invalid transaction_date format, empty product name, invalid quantity type
                "order_id": "TXN-201", "transaction_date": "2026/06/18", "customer_id": "C-2",
                "product_name": "", "product_category": "Home Goods", "quantity": "invalid_qty", "amount": "12.50",
                "payment_mode": "BadMode", "payment_status": "Success", "country": "India", "phone_number": "9876543210"
            }
        ])
        df.to_csv(csv_path, index=False)
        
        # 2. Run validator
        result = validate_transaction_file(csv_path, "invalid_data.csv")
        
        # 3. Assert checks
        self.assertTrue(result["success"])
        self.assertEqual(result["total_records"], 2)
        self.assertEqual(result["valid_count"], 0)
        self.assertEqual(result["invalid_count"], 2)
        
        # Check specific error counts
        # Row 2 (Excel row 2): amount is negative, phone is invalid for Singapore (2 errors)
        # Row 3 (Excel row 3): order_id duplicate, date invalid format, product_name empty, quantity invalid type, payment_mode invalid (5 errors)
        # Total errors = 7
        self.assertEqual(len(result["errors"]), 7)
        
        # Check that error CSV and clean CSV are created
        self.assertTrue(os.path.exists(os.path.join(UPLOAD_FOLDER, result["clean_file_path"])))
        self.assertTrue(os.path.exists(os.path.join(UPLOAD_FOLDER, result["error_file_path"])))

    def test_large_file_split(self):
        # 1. Create a large CSV file (> 1000 rows)
        csv_path = os.path.join(self.test_dir, "large_data.csv")
        
        rows = []
        for i in range(1200):
            rows.append({
                "order_id": f"TXN-L-{i}", "transaction_date": "18-06-2026", "customer_id": f"C-{i}",
                "product_name": f"Product {i}", "product_category": "Cat A", "quantity": "1", "amount": "100.00",
                "payment_mode": "Credit Card", "payment_status": "Success", "country": "India", "phone_number": "9876543210"
            })
            
        df = pd.DataFrame(rows)
        df.to_csv(csv_path, index=False)
        
        # 2. Run validator
        result = validate_transaction_file(csv_path, "large_data.csv")
        
        # 3. Assert split ZIP creation
        self.assertTrue(result["success"])
        self.assertEqual(result["total_records"], 1200)
        self.assertEqual(result["valid_count"], 1200)
        self.assertTrue(result["zip_created"])
        self.assertIsNotNone(result["split_zip_path"])
        self.assertTrue(os.path.exists(os.path.join(UPLOAD_FOLDER, result["split_zip_path"])))
        
        # Confirm split stats: 1200 records split into chunks of 500 rows = 3 chunks (500, 500, 200)
        self.assertEqual(len(result["split_chunks"]), 3)
        self.assertEqual(result["split_chunks"][0]["records_count"], 500)
        self.assertEqual(result["split_chunks"][1]["records_count"], 500)
        self.assertEqual(result["split_chunks"][2]["records_count"], 200)

    def test_messy_headers(self):
        # 1. Create a CSV file with mixed capitalization, whitespaces, and BOM representation
        csv_path = os.path.join(self.test_dir, "messy_headers.csv")
        df = pd.DataFrame([
            {
                "\ufeffOrder_Id": "TXN-301", " Transaction_Date ": "18-06-2026", "CUSTOMER_ID": "C-1",
                "product_name": "T-Shirt", "product_category": "Apparel", "quantity": "3", "amount": "45.00",
                "payment_mode": "Credit Card", "payment_status": "Success", "country": "India", "phone_number": "9876543210"
            }
        ])
        df.to_csv(csv_path, index=False)
        
        # 2. Run validator
        result = validate_transaction_file(csv_path, "messy_headers.csv")
        
        # 3. Assert success and metrics
        self.assertTrue(result["success"])
        self.assertEqual(result["total_records"], 1)
        self.assertEqual(result["valid_count"], 1)
        self.assertEqual(result["invalid_count"], 0)
        self.assertEqual(len(result["errors"]), 0)

if __name__ == "__main__":
    unittest.main()
