import os
import sys
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS

# Adjust python path if necessary
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend.config import UPLOAD_FOLDER
from backend.database import (
    init_db, get_all_rules, save_rule, delete_rule,
    save_validation_run, get_history, get_errors_for_job, get_all_error_logs
)
from backend.validator import validate_transaction_file
from backend.ai_summarizer import generate_ai_summary

app = Flask(__name__, static_folder="dist", static_url_path="")
CORS(app) # Enable CORS for development cross-port routing

@app.before_request
def log_request():
    print(f"[HTTP] {request.method} {request.path}", flush=True)

# Initialize SQLite database
with app.app_context():
    init_db()

# ----------------- CSV VALIDATION ENDPOINT -----------------
@app.route("/api/validate", methods=["POST"])
def validate_file():
    if "file" not in request.files:
        return jsonify({"success": False, "error": "No file part in the request"}), 400
        
    file = request.files["file"]
    if file.filename == "":
        return jsonify({"success": False, "error": "No selected file"}), 400
        
    if not file.filename.endswith(".csv"):
        return jsonify({"success": False, "error": "Invalid file type. Only CSV files are supported."}), 400

    # Save raw file temporarily
    temp_path = os.path.join(UPLOAD_FOLDER, f"temp_{file.filename}")
    file.save(temp_path)

    # Perform validation
    result = validate_transaction_file(temp_path, file.filename)
    
    # Clean up temp file
    if os.path.exists(temp_path):
        os.remove(temp_path)

    if not result["success"]:
        return jsonify({"success": False, "error": result["error"]}), 400

    # Generate AI summary
    summary = generate_ai_summary(
        result["total_records"],
        result["valid_count"],
        result["invalid_count"],
        result["errors"]
    )
    result["ai_summary"] = summary

    # Save metadata to database history
    job_id = save_validation_run(
        filename=file.filename,
        total_records=result["total_records"],
        valid_count=result["valid_count"],
        invalid_count=result["invalid_count"],
        success_percentage=result["success_percentage"],
        summary=summary,
        clean_path=result["clean_file_path"],
        error_path=result["error_file_path"],
        zip_path=result["split_zip_path"],
        errors=result["errors"]
    )
    
    result["job_id"] = job_id
    
    return jsonify(result)

# ----------------- HISTORY ENDPOINTS -----------------
@app.route("/api/history", methods=["GET"])
def get_validation_history():
    history = get_history()
    return jsonify({"success": True, "history": history})

@app.route("/api/history/<int:job_id>/errors", methods=["GET"])
def get_job_errors(job_id):
    errors = get_errors_for_job(job_id)
    return jsonify({"success": True, "errors": errors})

@app.route("/api/logs", methods=["GET"])
def get_recent_logs():
    limit = request.args.get("limit", default=200, type=int)
    logs = get_all_error_logs(limit)
    return jsonify({"success": True, "logs": logs})

# ----------------- PHONE RULES ENDPOINTS -----------------
@app.route("/api/rules", methods=["GET", "POST"])
def manage_rules():
    if request.method == "GET":
        rules = get_all_rules()
        return jsonify({"success": True, "rules": rules})
        
    elif request.method == "POST":
        data = request.json
        country = data.get("country")
        length = data.get("length")
        regex = data.get("regex")
        
        if not country or not length or not regex:
            return jsonify({"success": False, "error": "Missing mandatory fields: country, length, and regex"}), 400
            
        try:
            length = int(length)
        except ValueError:
            return jsonify({"success": False, "error": "Length must be a valid integer"}), 400
            
        save_rule(country, length, regex)
        return jsonify({"success": True, "message": f"Rule for {country} saved successfully."})

@app.route("/api/rules/<string:country>", methods=["DELETE"])
def delete_country_rule(country):
    delete_rule(country)
    return jsonify({"success": True, "message": f"Rule for {country} deleted successfully."})

# ----------------- DOWNLOADS ENDPOINT -----------------
@app.route("/api/download/<string:filename>", methods=["GET"])
def download_file(filename):
    # Prevent directory traversal attacks
    safe_filename = os.path.basename(filename)
    file_path = os.path.join(UPLOAD_FOLDER, safe_filename)
    if not os.path.exists(file_path):
        return jsonify({"success": False, "error": "Requested file not found"}), 404
        
    return send_from_directory(UPLOAD_FOLDER, safe_filename, as_attachment=True)

# ----------------- TEMPLATE DOWNLOAD ENDPOINT -----------------
@app.route("/api/sample-template", methods=["GET"])
def download_sample_template():
    sample_file_path = os.path.join(UPLOAD_FOLDER, "sample_transaction_template.csv")
    
    # Generate template dynamically if it doesn't exist
    if not os.path.exists(sample_file_path):
        # Sample headers
        import pandas as pd
        df = pd.DataFrame(columns=[
            "order_id", "transaction_date", "customer_id", "product_name", 
            "product_category", "quantity", "amount", "payment_mode", 
            "payment_status", "country", "phone_number"
        ])
        # Add a couple of sample records (valid and invalid)
        df.loc[0] = [
            "TXN-1001", "18-06-2026 10:15:00", "CUST-9901", "Dual-Chamber Air Fryer", 
            "Kitchen Appliances", "2", "189.50", "Credit Card", "Success", "Singapore", "81234567"
        ]
        df.loc[1] = [
            "TXN-1002", "19-06-2026", "CUST-9902", "Mechanical Keyboard", 
            "Computer Accessories", "1", "89.99", "UPI", "Success", "India", "9876543210"
        ]
        # Invalid phone number for Singapore (needs 8 digits) and negative amount error
        df.loc[2] = [
            "TXN-1003", "20-06-2026", "CUST-9903", "Noise Cancelling Headphones", 
            "Electronics", "1", "-150.00", "PayPal", "Failed", "Singapore", "91234"
        ]
        df.loc[3] = [
            "TXN-1004", "invalid-date", "CUST-9904", "Leather Office Chair", 
            "Furniture", "invalid_qty", "350.00", "Net Banking", "Success", "India", "123456"
        ]
        df.to_csv(sample_file_path, index=False)
        
    return send_from_directory(UPLOAD_FOLDER, "sample_transaction_template.csv", as_attachment=True)

# ----------------- SPA FALLBACK ROUTING -----------------
@app.route("/", defaults={"path": ""})
@app.route("/<path:path>")
def serve(path):
    if path != "" and os.path.exists(os.path.join(app.static_folder, path)):
        return send_from_directory(app.static_folder, path)
    else:
        return app.send_static_file("index.html")

if __name__ == "__main__":
    # In local development mode, run Flask on port 5000
    app.run(host="0.0.0.0", port=5000, debug=True)
