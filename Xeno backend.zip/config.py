import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
DATABASE_PATH = os.path.join(BASE_DIR, "database.sqlite")

# Create upload directory if it doesn't exist
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# CSV required columns
REQUIRED_COLUMNS = [
    "order_id",
    "transaction_date",
    "customer_id",
    "product_name",
    "product_category",
    "quantity",
    "amount",
    "payment_mode",
    "payment_status",
    "country",
    "phone_number"
]

# Validation configurations
ALLOWED_PAYMENT_MODES = [
    "Credit Card",
    "Debit Card",
    "UPI",
    "Net Banking",
    "Wallet",
    "Cash",
    "PayPal",
    "Google Pay",
    "Apple Pay"
]

ALLOWED_PAYMENT_STATUSES = [
    "Success",
    "Failed",
    "Pending",
    "Refunded"
]

# Default phone rules (digits validation)
# Configurable and extensible. Rules will be stored in SQLite to persist user edits.
DEFAULT_PHONE_RULES = {
    "India": {
        "length": 10,
        "regex": r"^\d{10}$"
    },
    "Singapore": {
        "length": 8,
        "regex": r"^\d{8}$"
    },
    "United States": {
        "length": 10,
        "regex": r"^\d{10}$"
    },
    "Malaysia": {
        "length": 9, # Can support either 9 or 10, let's keep basic length validation
        "regex": r"^\d{9,10}$"
    }
}

SPLIT_ROW_THRESHOLD = 1000
SPLIT_CHUNK_SIZE = 500
